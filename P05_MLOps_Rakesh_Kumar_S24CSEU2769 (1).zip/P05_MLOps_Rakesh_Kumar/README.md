# SCSE3040 — Practical 05: P05-config-tests

**Student:** Rakesh Kumar  
**Roll Number:** S24CSEU2769  
**Batch:** 74  
**Course:** Machine Learning Operations  
**Practical:** 05 — Settings in a File, Bugs Caught by a Robot

## Aim
1. Move model settings into a YAML configuration file.
2. Read the configuration from Python.
3. Train a delivery-time model using the configured settings.
4. Validate the project using automated pytest tests.

## Project structure
```text
P05_MLOps_Rakesh_Kumar/
├── config.yaml
├── conftest.py
├── orders.py
├── test_orders.py
├── test_model.py
├── test_speed.py
├── data/
│   └── delivery_times.csv
└── P05_S24CSEU2769.ipynb
```

## Run
Install dependencies:

```bash
pip install -r requirements.txt
```

Run all tests:

```bash
pytest -q
```

The test suite contains 10 tests.
